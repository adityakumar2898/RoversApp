package com.ankit.roversapp.activities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.ankit.roversapp.R;

public class LoginActivity extends AppCompatActivity implements View.OnTouchListener,View.OnClickListener{

    EditText usernameEdit, passwordEdit;
    String usernameString, passwordString;
    Button loginButton;
    Intent intent;
    TextView signup;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_actvity);


        usernameEdit = (EditText)findViewById(R.id.login_username_edit);
        passwordEdit = (EditText) findViewById(R.id.login_password_edit);
        loginButton = (Button) findViewById(R.id.login_button);
        signup = (TextView) findViewById(R.id.signup);

//        passwordEdit.setOnTouchListener(this);
        loginButton.setOnClickListener(this);
        signup.setOnClickListener(this);
    }



    @Override
    public void onClick(View view) {

        if(view.getId()==R.id.login_button) {

            gettingEditTextData();


            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);


            if (usernameString.equalsIgnoreCase("Pulkit") && passwordString.equals("123456")) {
                login();
            } else {
                Toast.makeText(this, "Invalid credentials", Toast.LENGTH_LONG).show();
            }

        }


        else if(view.getId()==R.id.signup)
        {
            intent=new Intent(LoginActivity.this,RegistrationActivity.class);
            startActivity(intent);
        }

//        if (usernameString.equals("") && passwordString.equals("")) {
//            usernameEdit.setError("Please Enter Username");
//            passwordEdit.setError("Please Enter Password");
//        } else if (usernameString.equals("")) {
//            usernameEdit.setError("Please Enter Username");
//        } else if (passwordString.equals("")) {
//            passwordEdit.setError("Please Enter Password");
//        } else {
//            login();
//        }
    }





    //Getting EditText Data
    public void gettingEditTextData()
    {
        usernameString=usernameEdit.getText().toString();
        passwordString=passwordEdit.getText().toString();
    }


    private void login() {
        intent=new Intent(LoginActivity.this,MainActivity.class);
        startActivity(intent);
        finish();
    }


    //OnTouch Events for EditTexts
    @Override
    public boolean onTouch(View view, MotionEvent motionEvent) {

//        gettingEditTextData();
//
//
//        if(usernameString.length()==0)
//        {
//            usernameEdit.setError("Please Enter Username");
//        }
//
        return false;
    }











}
